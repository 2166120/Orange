-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 17, 2019 at 03:25 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webtechlec`
--

-- --------------------------------------------------------

--
-- Table structure for table `css_identification`
--

DROP TABLE IF EXISTS `css_identification`;
CREATE TABLE IF NOT EXISTS `css_identification` (
  `Question` varchar(200) NOT NULL,
  `User's Answer` varchar(100) NOT NULL,
  `Correct Answer` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `css_identification`
--

INSERT INTO `css_identification` (`Question`, `User's Answer`, `Correct Answer`) VALUES
('CSS stands for?', '', 'Cascading Style Sheet'),
('What is the element used by the filter propert to blur image?', '', 'blur()'),
('What is the function property to create your own sophisticated effect on DOM elements?', '', 'DOM()'),
('What is the function that flips an n element\'s colors, for use  by the filter property?', '', 'invert()'),
('What is CSS property that is used to set text formatting?', '', 'text-decoration'),
('What is the text-decoration value  specifies each line of text has a live above it?', '', 'overline'),
(' In CSS, h1 can be called as _____', '', 'SELECTORS'),
('What is the selector used to specify a rule to bind a particular unique element?', '', 'ID'),
('In CSS, font-size is also called as?', '', 'Property-Name'),
('_______ has introduced text, list, margin, border, color, and background properties.', '', 'CSS'),
('What is the dag used to embed css in html page?', '', '<style>'),
('What selects a normal, or small-caps face from font family?', '', 'font-variant'),
('What allows the font to expand or condense the widths for a normal, condensed, or expanded font?', '', 'font-expand'),
(' _______ has a grammar but unlike traditional (X)HTML it is not defined with a document type definition.', '', 'css 2.1'),
('What is the CSS property defining bottom-left-corner shape of the border?', '', 'border-bottom-left-radius'),
('What is the CSS property that sets the width of an element\'s bottom border?', '', 'border-bottom-width'),
('What is the CSS property border-color property sets the color of an element\'s four boarders?', '', 'border-color'),
('It is the property that can be used for collapsing the borders betwwen table cells?', '', 'border-collapse'),
(' What is the unit represent the viewport\'s width', '', 'vw'),
('What is the Protocol enables a hyperlink to acces a file on the local file system?', '', 'file'),
(' What is the attribute specifies the URL of the linked resource?', '', 'href'),
('What is the element used for linking a External Files to the html page?', '', '<link>'),
(' What color has the value #ff0000?', '', 'red'),
('The ______property is used to set the color of the text.', '', 'color'),
('A ___________ is used to define a special state of an element.', '', 'pseudo-id');

-- --------------------------------------------------------

--
-- Table structure for table `css_mulitiplechoice`
--

DROP TABLE IF EXISTS `css_mulitiplechoice`;
CREATE TABLE IF NOT EXISTS `css_mulitiplechoice` (
  `Questions` varchar(200) NOT NULL,
  `A` varchar(100) NOT NULL,
  `B` varchar(100) NOT NULL,
  `C` varchar(100) NOT NULL,
  `D` varchar(100) NOT NULL,
  `Correct Answer` varchar(1) NOT NULL,
  `User's Answer` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `css_mulitiplechoice`
--

INSERT INTO `css_mulitiplechoice` (`Questions`, `A`, `B`, `C`, `D`, `Correct Answer`, `User's Answer`) VALUES
('If we want define style for an unique element, then which css selector will we use?', 'ID', 'TEXT', 'CLASS', 'NAME', 'A', ''),
('If we don\'t want to allow a floating div to the left side of an element, which css property will we use?', 'MARGIN ', 'CLEAR', 'FLOAT', 'PADDING', 'B', ''),
('If we want to wrap a block of text around an image, which css poperty will we use?', 'WRAP', 'PUSH', 'FLOAT', 'ALIGN', 'C', ''),
('What should be the table width, so that the width of a table adjust to the current width of the browser window?', '640 pixels', '100%', 'full-screen', '1024 px', 'B', ''),
('Which emelents is used the <head> section on a HTML, if we want to use an external style to decorate?', 'src', 'link', 'style', 'css', 'B', ''),
('Which attribute can be added to many HTML elements to identify them as a member of a specific group?', 'ID', 'DIV', 'CLASS', 'SPAN', 'C', ''),
('When we write <img src=\"img.png\">, what \"img.png\" inside the double qoute implies?', 'ELEMENT', 'ATTRIBUTE', 'VALUE', 'OPERATOR', 'C', ''),
('How can we write comment along with CSS code?', '/* a commnet */', '// a comment // ', '/ a comment / ', '<\' a commnet \'>', 'A', ''),
('Which css property you will use if you want to add some margin between a DIV\'s border and its inner text?', 'SPACING', 'MARGIN', 'PADDING', 'INNER-MARGIN', 'C', ''),
('Which CSS property is used to control the text size of an element?', 'FONT-STYLE', 'TEXT-SIZE', 'FONT-SIZE', 'TEXT-STYLE', 'C', ''),
('What type of selectoris used in this case?\r\np {line-height: 150%;}', 'CLASS SELECTORS', 'ELEMENT SELECTORS', 'ID SELECTORS', 'NONE OF THE ABOVE', 'B', ''),
('By applying an __ a style can be applied to just a single tag.', 'CLASS RULE', 'ELEMENT RULE', 'ID RULE', 'NONE OF THE ABOVE', 'C', ''),
('The __ attribute is used to define athe name(s) of the class(es) to which a particular tag belongs.', 'CLASS', 'ELEMENT', 'ID ', 'NONE OF THE ABOVE', 'A', ''),
('What will be the output of below mentioned code snippet?\r\np strong{background-color: yellow;}', 'Strong have yellow background', 'Strong element within a p element have a yellow background', 'Both p and strong have yellow background', 'None of the Above', 'B', ''),
('A similar rule called the  __ is specified using the plus sign and is used to select elements that would be siblings of each other.', 'Class Selectors', 'Attribute Selectors', 'Adjacent-Sibling Selector', 'None of the Above', 'C', ''),
('Which of the following selector selects ny tag with an ID attribute set?', 'E#id', '.class', '#id', '*', '', 'C'),
('Which oof the following selectors selects direct descendents?', 'E &gt; F', 'E F', 'E + F', 'E - F', 'A', ''),
('Which of the following selectors selects siblings', 'E ~ F', 'E.class', '*', 'E, F, G', 'A', ''),
('Which of the following selectors selects the specified elements of type E with a particular class value?', 'E.class', 'E ~ F', '*', 'E, F, G', 'A', ''),
('Which of the following selectors selects adjacent sibllings?', 'E  &gt; F', 'E F', 'E + F', 'E ~ F', 'C', ''),
('Which of the following color has this value #ff0000?', 'BLUE', 'YELLOW', 'RED ', 'GREEN', 'C', ''),
('Which of the following attributes specifies the URL of the linked resource?', 'src', 'link', 'rel', 'href', 'D', ''),
('Which of the following element is used for linking a External Files to the HTML page?', '<script>', '<style>\r\n', '<link>', 'All of the above', 'C', ''),
('Which of the following protocol enables a hyperlink to access a file on the local file system?', 'https', 'ftp', 'file', 'telnet', 'C', ''),
('Which of the following is not a attribute of the audio element?', 'controls', 'src', 'check', 'loop', 'C', ''),
('Which of the following selectors selects any tag with an id attribute set?', 'E#id', '.class', '#id', '*', 'C', '');

-- --------------------------------------------------------

--
-- Table structure for table `http_identification`
--

DROP TABLE IF EXISTS `http_identification`;
CREATE TABLE IF NOT EXISTS `http_identification` (
  `Question` varchar(300) NOT NULL,
  `User's Answer` varchar(200) NOT NULL,
  `Correct Answer` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `http_identification`
--

INSERT INTO `http_identification` (`Question`, `User's Answer`, `Correct Answer`) VALUES
('What does HTTP stands for?', '', 'Hypertext Transfer Protocol'),
('Who invented HTTP?', '', 'Tim Berners-Lee'),
('What does W3C stands for?', '', 'World Wide Web Consortium'),
('What port does HTTP use by default? Write the answer in number?', '', '80'),
('What port does HTTPS use by default? Write the answer in number?', '', '443'),
('HTTP is based on a ____ architecture.', '', 'client-server'),
('What part of HTTP resource address is \"https\" in \"http://www.google.com\"?', '', 'scheme'),
('Is HTTP stateful or stateless?', '', 'stateless'),
('How is HTTP 1.1 written in an HTTP request message?', '', 'HTTP/1.1'),
('What HTTP request method transfers a current selected representation of a target resource?', '', 'GET'),
('What HTTP request method retrieves metadata about the target resource representation without transfering the data itself?', '', 'HEAD'),
('What HTTP request method is used in submitting HTML form data?', '', 'POST'),
('What HTTP request method creates or replaces the state of the target resource?', '', 'PUT'),
('What HTTP request method requests the establishment of a tunnel to the destination origin server?', '', 'CONNECT'),
('What HTTP request method is used for testing the request/response chain?', '', 'TRACE'),
('What HTTP request method removes the association between the target resource and its current functionality?', '', 'DELETE'),
('What is the HTTP request property wherein the method\'s semantics is essentially read-only?', '', 'safe'),
('What is the HTTP resquest property that indicates that thebresponse to a method is allowed to be stored for future use?', '', 'cacheable'),
('In this HTTP request method, the target may be *.', '', 'OPTIONS'),
('Cache-control and Cacheable are __ header fields.', '', 'general'),
('Expires and Las-Modified are __ header fields.', '', 'entity'),
('ETag and Location are __ header fields.', '', 'response'),
('Host and TE are __ header fields.', '', 'request'),
('What header field is used for backwards compatibility with HTTP/1.0 caches?', '', 'pragma'),
('What does 206 HTTP status code stands for?', '', 'Partial Content');

-- --------------------------------------------------------

--
-- Table structure for table `http_multiplechoice`
--

DROP TABLE IF EXISTS `http_multiplechoice`;
CREATE TABLE IF NOT EXISTS `http_multiplechoice` (
  `Questions` varchar(200) NOT NULL,
  `A` varchar(100) NOT NULL,
  `B` varchar(100) NOT NULL,
  `C` varchar(100) NOT NULL,
  `D` varchar(100) NOT NULL,
  `Correct Answer` varchar(1) NOT NULL,
  `User's Answer` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `http_multiplechoice`
--

INSERT INTO `http_multiplechoice` (`Questions`, `A`, `B`, `C`, `D`, `Correct Answer`, `User's Answer`) VALUES
(' HTTP is called a ______ protocol because the connection between the browser and the server is lost once the transaction ends.', 'Stateless', 'Secure', 'Stateful', 'Gopher', 'A', ''),
('The ____ method calls a representation of a specific resource. Requests using this method should only retrieve data \r\nand nothing more.', 'HEAD', 'POST', 'GET', 'DELETE', 'C', ''),
('The ____ method asks for a response identical to that of a GET request, but without the response body.', 'HEAD', 'POST', 'GET', 'DELETE', 'A', ''),
('Choose a safe method', 'GET', 'PATCH', 'DELETE', 'CONNECT', 'A', ''),
('Choose the idempotent method', 'PATCH', 'GET', 'HEAD', 'DELETE', 'D', ''),
('HTTP', 'Hypertext Transformation Protocol', 'Hypertext Transfer Protocol', 'Hypertext Transform Protocol', 'Hypertext Transfer Proxy', 'B', ''),
('Informational Status Code', '1XX', '2XX', '3XX', '4XX', 'A', ''),
('Server Error Status Code', '2XX', '3XX', '4XX', '5XX', 'D', ''),
('Successful Status Code', '2XX', '3XX', '4XX', '5XX', 'A', ''),
('Redirection Status Code', '1XX', '2XX', '3XX', '4XX', 'C', ''),
('Client Error Status Code', '2XX\r\n', '4XX', '3XX', '5XX', 'B', ''),
('Who initiated the development of HTTP', 'Tim Berners-Lee', 'Ted Nelson', 'Vannevar Bush', 'Larry Page', 'A', ''),
('Gone Status Code', '101', '202', '303', '410', 'D', ''),
('Switchibg Protocol Status Code', '102', '100', '101', '104', 'C', ''),
('Created Status Code', '201', '200', '204', '205', 'A', ''),
('Found Status Code', '300', '301\r\n', '302', '303', 'C', ''),
('Bad Gate Status Code', '501', '502', '503', '504', 'B', ''),
('Continue Status Code', '100', '102', '104', '106', 'A', ''),
('OK Status Code', '205', '203', '201', '200', 'D', ''),
('Use Proxy Status Code', '304', '305', '306', '307', 'B', ''),
('Bad Request Status Code', '400', '401', '402', '403', 'A', ''),
('Provided as key value pairs with ampersand separators between key/value pairs.', 'SCHEME', 'PATH', 'QUERY', 'FRAGMENT IDENTIFIER', 'C', ''),
('Request information about the communication ___ available for the target resource', 'DELETE', 'OPTIONS', 'PUT', 'CONNECT', 'B', ''),
('Typically used for testing/diagnstics of the request/respoce chain', 'TRACE', 'CONNNECT', 'HEAD', 'GET', 'A', ''),
('Not Found Status Code', '401', '402', '404', '405', 'C', '');

-- --------------------------------------------------------

--
-- Table structure for table `js_identification`
--

DROP TABLE IF EXISTS `js_identification`;
CREATE TABLE IF NOT EXISTS `js_identification` (
  `Question` varchar(200) NOT NULL,
  `User's Answer` varchar(100) NOT NULL,
  `Correct Answer` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `js_identification`
--

INSERT INTO `js_identification` (`Question`, `User's Answer`, `Correct Answer`) VALUES
('What does JS DOM stands for?', '', 'Java Script Document Object Model.'),
('It is a programming interface for HTML and XML documents?', '', 'DOM'),
(' It has standardized javascript?', '', 'ECMAScript'),
('It is a scripting language that can be inserted into an HTML page that can be understood by web browsers.', '', 'JavaScript\r\n'),
('It is a specific page in a session?', '', 'Viewstate'),
(' It is a specific data to users that can be accessed across pages in the web application?', '', 'SessionState'),
('It is used to present a no value or no object in the application?', '', 'NULL'),
('function that returns true if the argument is not a number otherwise it returns false', '', 'isNaN function'),
('A number in javascript  that can be derived by dividing negative number by zero.', '', 'Negative Infinity\r\n'),
(' Allows the user to enter input by providing a text box.', '', 'Prompt box'),
(' It is used to assign a number to a variable that can be also assigned to a string?', '', 'Variable typing'),
('The function that s used to delete a property as well as its value?', '', 'Delete'),
('What is the data type of all variables in javascript', '', ' Object Data Type'),
(' A list of node extracted from a document', '', 'NodeList'),
('A code to create a new element.', '', '<p>'),
('The property that specifies the name of a node.', '', 'nodeName'),
('The property that specifies the value of a node.', '', 'nodeValue'),
('The property the specifies the type of a node.', '', 'nodeType'),
('Can be used to write directly to the html output stream', '', 'document.write()'),
('The maximum size in code units for the separate storage areas used by localStorage and sessionStorage.', '', 'storageQouta'),
('Every object located within a document is a node of some kind. In an HTML document, each node is an element.', '', 'Node'),
('Returns an Element object representing the element whose id property matches the specified string.', '', 'querySelector()'),
('object describing the DOM element object matching the specified ID, or null if no matching element was found in the document.', '', 'Element'),
('Adds a node to the end of the list of children of a specified parent node.', '', 'Node.appendChild()'),
('The handler function to be called when the window’s load event fires.', '', 'functionRef');

-- --------------------------------------------------------

--
-- Table structure for table `js_multiplechoice`
--

DROP TABLE IF EXISTS `js_multiplechoice`;
CREATE TABLE IF NOT EXISTS `js_multiplechoice` (
  `Question` varchar(200) NOT NULL,
  `A` varchar(100) NOT NULL,
  `B` varchar(100) NOT NULL,
  `C` varchar(100) NOT NULL,
  `D` varchar(100) NOT NULL,
  `Correct Answer` varchar(1) NOT NULL,
  `User's Answer` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `js_multiplechoice`
--

INSERT INTO `js_multiplechoice` (`Question`, `A`, `B`, `C`, `D`, `Correct Answer`, `User's Answer`) VALUES
('The following are JavaScript Data Types except for 1', 'Number', 'String', 'Boolean', 'Function', 'D', ''),
('What company developed javascript?', 'Netscape', 'Oracle', 'Amazon', 'IBM', 'A', ''),
('How many levels does JSDOM have?', '0', '2', '10', '4', 'D', ''),
('The following are symbols used for comments for java script except for one.', '//', '/', '/*', '*/', 'B', ''),
('The following are types of pop up boxes in Javascript except for 1', 'Alert', 'Confirm', 'Script', 'Prompt', 'C', ''),
('HTML DOM methods are ______ you can perform on html elements.', 'values', 'actions', 'objects', 'property', 'B', ''),
('HTM: DOM properties are ______ of html elements that you can set or change.', 'property', 'actions', 'values', 'ojects', 'C', ''),
('In the DOM, all html elements are defined as ______.', 'values', 'property', 'objects', 'actions', 'C', ''),
(' A ______ is a value that you can get or set like changing the content of an HTML element.', 'property', 'values', 'objects', 'method', 'A', ''),
('A ______ is a an action you can do like add or deleting and html element.', 'set', 'post', 'method', 'property', 'C', ''),
('The most common way to accesss an html element is to use the ______ of the element.', 'div', 'line', 'id', 'property', 'C', ''),
('The easiest way to get the content of an element is by using the ______ property.', 'innerHTML', 'outerHTML', 'sideHTML', 'centerHTML\r\n', 'A', ''),
('______ can be used to write directly to the html output stream.', 'document.read()', 'document.write()', 'document.get()', 'document.delete()', 'B', ''),
('The ______ event can be used to chec the visitor\'s browser type and browser version, and load the proper version of the web page based on the information.', 'onload', 'onunload', 'uniload', 'onchange', 'A', ''),
('The ______ event is often used in combination with validation of input fields.', 'onload', 'onchange', 'uniload', 'onunload', 'B', ''),
('Change the background-color of an input ifield when it gets focus.', 'onload', 'onchange', 'onfocus', 'oncolor', 'D', ''),
('Change the color of an element when the cursor moves over it.', 'Change events', 'color events', 'Mouse events', 'Animation events ', 'C', ''),
('The ______ method attaches and event handler to the specified element.\r\n', 'getEventListener()', 'postEventListener()', 'removeEventListener()', 'addEventListener()', 'D', ''),
('Easily remove an event listener.', 'removeEventListener()', 'deleteEventListener()', 'eraseEventListener()', 'undoEventListener()', 'A', ''),
('Method to attach an event handlers to the element.\r\n', 'addEvent()', 'attachEvent()', 'postEvent()', 'getEvent()', 'B', ''),
('The body of the document', 'document.body', 'document.documentBody', 'document.documentElement', 'document.htmlBody', 'A', ''),
('Specifies the name of a node.', 'nodeId', 'nodeName', 'nodeType', 'nodeValue', 'B', ''),
('Specifies the value of a node.\r\n', 'nodeId', 'nodeType', 'nodeValue', 'nodeName', 'C', ''),
('Returns the type of a node', 'nodeName', 'nodeType', 'nodeId', 'nodeName', 'B', ''),
('This code creates a new element', '<a>', '<div>', '<p>', '<img>', 'C', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
